#define SystemSevenOrLater 1

#include <Carbon/Carbon.r>

resource 'STR#' (127)
{{
"A trivial Example plugin!"
}};

resource 'STR#' (128)
{{
"trivial/very",
""
}};

resource 'STR#' (126)
{{
"Plugin for trivial uses"
}};
